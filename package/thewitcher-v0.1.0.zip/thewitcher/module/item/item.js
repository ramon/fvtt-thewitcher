export default class WitcherItem extends Item {
}
