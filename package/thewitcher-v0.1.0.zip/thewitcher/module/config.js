export const THEWITCHER = {
    professionAbilities: {
        "int": "THEWITCHER.actor.abilities.int.abbr",
        "ref": "THEWITCHER.actor.abilities.ref.abbr",
        "dex": "THEWITCHER.actor.abilities.dex.abbr",
        "body": "THEWITCHER.actor.abilities.body.abbr",
        "spd": "THEWITCHER.actor.abilities.spd.abbr",
        "emp": "THEWITCHER.actor.abilities.emp.abbr",
        "cra": "THEWITCHER.actor.abilities.cra.abbr",
        "will": "THEWITCHER.actor.abilities.will.abbr"
    }
};
